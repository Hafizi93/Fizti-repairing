
import React from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet } from 'react-native';

export default function App() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Fizti Repair Service</Text>

      <View style={styles.card}>
        <Text style={styles.heading}>Log Masuk</Text>
        <TextInput style={styles.input} placeholder="Nombor Telefon" />
        <TextInput style={styles.input} placeholder="Kata Laluan" secureTextEntry />
        <Button title="Masuk" onPress={() => {}} />
        <Button title="Daftar Akaun" onPress={() => {}} />
      </View>

      <View style={styles.card}>
        <Button title="Buat Tempahan" onPress={() => {}} />
        <Button title="Lihat Status Tempahan" onPress={() => {}} />
        <Button title="Hubungi Kami" onPress={() => {}} />
      </View>

      <View style={styles.card}>
        <Text style={styles.heading}>Tempahan Repair</Text>
        <TextInput style={styles.input} placeholder="Jenis Masalah (Contoh: Skrin Pecah)" />
        <TextInput style={styles.input} placeholder="Tarikh" />
        <TextInput style={styles.input} placeholder="Masa" />
        <TextInput style={styles.input} placeholder="Nota Tambahan" multiline />
        <Button title="Hantar Tempahan" onPress={() => {}} />
      </View>

      <View style={styles.card}>
        <Text style={styles.heading}>Penghantaran Lokasi</Text>
        <Button title="Hantar Lokasi Saya" onPress={() => {}} />
        <TextInput style={styles.input} placeholder="Masukkan Alamat Manual" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
  },
  title: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  heading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
});
